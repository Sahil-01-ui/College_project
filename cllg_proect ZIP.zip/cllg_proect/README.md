# Smart Budget - Personal Budgeting Application

A full-stack web application for personal budget management with expense tracking, categorization, and financial goal monitoring.

## 🏗️ Architecture

This application follows a **separated architecture** with clear separation of concerns:

- **Backend (API Server)**: Handles database connections, business logic, and API endpoints
- **Frontend (Web Client)**: Handles UI, user interactions, and communicates with backend via HTTP API
- **Independent Deployment**: Both components can run independently and be deployed separately

## 🚀 Features

- **User Authentication**: Secure registration and login with bcrypt password hashing
- **Expense Tracking**: Add, view, and categorize income and expenses
- **Smart Categorization**: Predefined categories for easy expense organization
- **Dashboard**: Visual overview of financial status and recent transactions
- **Responsive Design**: Works on desktop and mobile devices
- **Database Fallback**: Works with MongoDB or in-memory storage when database is unavailable
- **API-First Design**: RESTful API that can be used by multiple clients

## 📁 Project Structure

```
smart-budget/
├── backend/
│   ├── controllers/
│   │   └── auth.js              # Authentication logic
│   ├── middleware/
│   │   ├── errorHandler.js      # Global error handling
│   │   └── validation.js        # Input validation
│   ├── models/
│   │   ├── User.js              # User schema
│   │   └── Transaction.js       # Transaction schema
│   ├── routes/
│   │   ├── auth.js              # Authentication routes
│   │   └── transactions.js      # Transaction routes
│   ├── utils/
│   │   └── memoryStore.js       # In-memory storage fallback
│   ├── .env                     # Environment variables
│   └── server.js                # Main server file
├── frontend/
│   ├── index.html               # Landing page
│   ├── signin.html              # Sign in page
│   ├── signup.html              # Sign up page
│   ├── dashboard.html           # Main dashboard
│   ├── signin.js                # Sign in functionality
│   ├── signup.js                # Sign up functionality
│   ├── dashboard.js             # Dashboard functionality
│   ├── main.js                  # Navigation and UI
│   └── styles.css               # Application styles
├── package.json                 # Dependencies and scripts
└── README.md                    # This file
```

## 🛠️ Prerequisites

- **Node.js** (version 14.0 or higher)
- **npm** (comes with Node.js)
- **MongoDB** (optional - app works without it using memory storage)

## 📦 Installation

1. **Clone or download the project**
   ```bash
   cd path/to/smart-budget
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Configure environment variables** (optional)
   - Edit `backend/.env` to set your MongoDB connection string
   - Default configuration works with local MongoDB or memory storage

## 🚀 Running the Application

### Option 1: Run Both Components Independently (Recommended)

#### Step 1: Start the Backend API Server
```bash
# Navigate to backend directory
cd backend

# Install dependencies (first time only)
npm install

# Start the API server
npm start
```

**Expected Output:**
```
🚀 Smart Budget API Server running on http://localhost:5000
📡 API Endpoints available at http://localhost:5000/api/
📊 Database: Connected and ready
🔍 Health check: http://localhost:5000/api/health
📝 Note: This is API-only server. Frontend should run separately.
```

#### Step 2: Start the Frontend Server (New Terminal)
```bash
# Navigate to frontend directory
cd frontend

# Install dependencies (first time only)
npm install

# Start the frontend server
npm start
```

**Expected Output:**
```
Starting up http-server, serving ./
Available on:
  http://127.0.0.1:3000
Hit CTRL-C to stop the server
```

#### Step 3: Access the Application
- **Frontend**: http://localhost:3000
- **Backend API**: http://localhost:5000/api/
- **Health Check**: http://localhost:5000/api/health

### Option 2: Quick Start Scripts
```bash
# Windows - Start backend
cd backend && start-backend.bat

# Windows - Start frontend (new terminal)
cd frontend && start-frontend.bat
```

## 🧪 Testing the Application

### Backend API Testing

#### 1. Test API Health
```bash
# Using curl
curl http://localhost:5000/api/health

# Using PowerShell
Invoke-WebRequest -Uri "http://localhost:5000/api/health" -Method GET
```

**Expected Response:**
```json
{
  "status": "OK",
  "message": "Smart Budget API is running",
  "timestamp": "2024-01-01T12:00:00.000Z",
  "database": "connected"
}
```

#### 2. Test User Registration API
```bash
curl -X POST http://localhost:5000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"email":"test@example.com","password":"password123"}'
```

### Frontend Testing

#### 1. User Registration Flow
1. Go to `http://localhost:3000`
2. Click "Sign Up" or "Get Started"
3. Enter email and password (minimum 6 characters)
4. Click "Register"
5. **Expected**: Success message and redirect to sign-in

#### 2. User Login Flow
1. Go to sign in page
2. Enter your credentials
3. Click "Sign In"
4. **Expected**: Redirect to dashboard with user email displayed

#### 3. Add Transaction Flow
1. On the dashboard, click "Add Transaction"
2. Fill in the transaction details:
   - Type: Income or Expense
   - Category: Select from predefined categories
   - Amount: Enter the amount
   - Description: Brief description
   - Date: Transaction date
3. Click "Add Transaction"
4. **Expected**: Transaction appears in list immediately

#### 4. View Transactions
- All transactions appear in the "Recent Transactions" section
- Transactions are sorted by date (newest first)
- Data persists between sessions (if database connected)

### Integration Testing

#### 1. Test Frontend-Backend Communication
1. **Start both servers** (backend on :5000, frontend on :3000)
2. **Open browser dev tools** (F12) → Network tab
3. **Perform user registration** on frontend
4. **Verify API call** appears in Network tab to `localhost:5000/api/auth/register`
5. **Check backend logs** for incoming request

#### 2. Test Database Integration
1. **Register a new user** via frontend
2. **Check backend logs** for database operations
3. **Restart backend server**
4. **Try logging in** with same credentials
5. **Expected**: Login should work (data persisted)

## 🔧 Configuration

### Environment Variables (`backend/.env`)
```env
MONGO_URI=mongodb://localhost:27017/smartbudget
MONGO_URI_CLOUD=your_cloud_mongodb_connection_string
PORT=5000
NODE_ENV=development
```

### Database Options
1. **Local MongoDB**: Install MongoDB locally and use default settings
2. **Cloud MongoDB**: Use MongoDB Atlas or other cloud providers
3. **Memory Storage**: No setup required - automatic fallback

## 🚨 Troubleshooting

### Backend Issues

#### 1. Port 5000 already in use
```bash
# Find and kill the process
netstat -ano | findstr :5000
taskkill /PID [PID_NUMBER] /F

# Or use a different port
set PORT=5001 && npm start
```

#### 2. MongoDB connection failed
- **Expected behavior**: App automatically uses memory storage
- **Check MongoDB service**: Ensure MongoDB is running locally
- **Verify connection**: Check connection string in `backend/.env`
- **Test connection**: Use MongoDB Compass or mongo shell

#### 3. Backend won't start
```bash
# Check Node.js version
node --version  # Should be 14.0+

# Clear node_modules and reinstall
rm -rf node_modules package-lock.json
npm install

# Check for syntax errors
node --check server.js
```

### Frontend Issues

#### 1. Port 3000 already in use
```bash
# Use different port
npx http-server -p 3001 -c-1 --cors

# Or kill existing process
netstat -ano | findstr :3000
taskkill /PID [PID_NUMBER] /F
```

#### 2. Frontend can't connect to backend
- **Check backend is running**: Visit http://localhost:5000/api/health
- **Check CORS**: Backend includes CORS middleware
- **Check browser console**: Look for network errors (F12)
- **Verify API URLs**: Should point to localhost:5000

#### 3. Frontend not loading
- **Check http-server**: Ensure it's installed (`npm install -g http-server`)
- **Check file paths**: Verify all HTML/JS/CSS files exist
- **Clear browser cache**: Hard refresh (Ctrl+F5)

### Integration Issues

#### 1. API calls failing
```javascript
// Check browser console for errors like:
// "Failed to fetch" - Backend not running
// "CORS error" - CORS configuration issue
// "404 Not Found" - Wrong API endpoint
```

#### 2. Data not persisting
- **Check database connection**: Backend logs show database status
- **Memory store mode**: Data only persists during session
- **Database credentials**: Verify MongoDB connection string

#### 3. Authentication not working
- **Check localStorage**: User data should be stored after login
- **Check API responses**: Should return user object
- **Check password hashing**: Ensure bcrypt is working properly

### Development Mode
For development with auto-restart:
```bash
npm install -g nodemon
nodemon backend/server.js
```

## 🔒 Security Features

- **Password Hashing**: Uses bcrypt with salt rounds
- **Input Validation**: Server-side validation for all inputs
- **Error Handling**: Comprehensive error handling and logging
- **CORS Protection**: Configured for cross-origin requests

## 📱 Browser Compatibility

- Chrome (recommended)
- Firefox
- Safari
- Edge

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## 📄 License

This project is licensed under the ISC License.

## 🆘 Support

If you encounter any issues:
1. Check the troubleshooting section above
2. Review server console logs
3. Check browser developer tools console
4. Ensure all prerequisites are installed

---

**Happy Budgeting! 💰**
