// Simple test to verify the backend server starts without errors
const { spawn } = require('child_process');
const path = require('path');

console.log('🧪 Testing Smart Budget Backend Server Startup...\n');

// Change to backend directory
const backendDir = path.join(__dirname, 'backend');
console.log(`📁 Backend directory: ${backendDir}`);

// Start the server
const serverProcess = spawn('node', ['server.js'], {
  cwd: backendDir,
  stdio: 'pipe'
});

let startupOutput = '';
let hasStarted = false;
let hasError = false;

// Capture stdout
serverProcess.stdout.on('data', (data) => {
  const output = data.toString();
  startupOutput += output;
  console.log('📤 STDOUT:', output.trim());
  
  if (output.includes('Smart Budget API Server running')) {
    hasStarted = true;
    console.log('✅ Server started successfully!');
    setTimeout(() => {
      console.log('\n🛑 Stopping server...');
      serverProcess.kill('SIGTERM');
    }, 2000);
  }
});

// Capture stderr
serverProcess.stderr.on('data', (data) => {
  const error = data.toString();
  console.log('❌ STDERR:', error.trim());
  hasError = true;
  
  if (error.includes('path-to-regexp')) {
    console.log('🔍 DETECTED: path-to-regexp error');
  }
  
  if (error.includes('EADDRINUSE')) {
    console.log('🔍 DETECTED: Port already in use error');
  }
});

// Handle process exit
serverProcess.on('close', (code) => {
  console.log(`\n📊 Server process exited with code: ${code}`);
  
  if (hasStarted && !hasError) {
    console.log('🎉 SUCCESS: Server started and stopped cleanly!');
  } else if (hasError) {
    console.log('❌ FAILURE: Server encountered errors during startup');
  } else {
    console.log('⚠️  WARNING: Server did not start properly');
  }
  
  console.log('\n📝 Startup Output:');
  console.log(startupOutput);
});

// Handle process error
serverProcess.on('error', (error) => {
  console.log('💥 Process Error:', error.message);
});

// Timeout after 10 seconds
setTimeout(() => {
  if (!hasStarted) {
    console.log('\n⏰ Timeout: Server did not start within 10 seconds');
    serverProcess.kill('SIGTERM');
  }
}, 10000);
