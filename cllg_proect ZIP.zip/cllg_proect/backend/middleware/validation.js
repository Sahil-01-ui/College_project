// Validation middleware functions

const validateEmail = (email) => {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
};

const validatePassword = (password) => {
  return password && password.length >= 6;
};

const validateUserRegistration = (req, res, next) => {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({ 
      message: 'Email and password are required' 
    });
  }

  if (!validateEmail(email)) {
    return res.status(400).json({ 
      message: 'Please provide a valid email address' 
    });
  }

  if (!validatePassword(password)) {
    return res.status(400).json({ 
      message: 'Password must be at least 6 characters long' 
    });
  }

  next();
};

const validateUserLogin = (req, res, next) => {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({ 
      message: 'Email and password are required' 
    });
  }

  if (!validateEmail(email)) {
    return res.status(400).json({ 
      message: 'Please provide a valid email address' 
    });
  }

  next();
};

const validateTransaction = (req, res, next) => {
  const { userId, type, category, amount, description } = req.body;

  if (!userId || !type || !category || !amount || !description) {
    return res.status(400).json({ 
      message: 'All fields (userId, type, category, amount, description) are required' 
    });
  }

  if (!['income', 'expense'].includes(type)) {
    return res.status(400).json({ 
      message: 'Type must be either "income" or "expense"' 
    });
  }

  if (isNaN(amount) || amount <= 0) {
    return res.status(400).json({ 
      message: 'Amount must be a positive number' 
    });
  }

  next();
};

module.exports = {
  validateUserRegistration,
  validateUserLogin,
  validateTransaction
};
