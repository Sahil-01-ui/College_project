const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const path = require("path");
require("dotenv").config({ path: path.join(__dirname, '.env') });

const authRoutes = require("./routes/auth-clean");
const transactionRoutes = require("./routes/transactions");
const errorHandler = require("./middleware/errorHandler");

const app = express();

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({
    status: 'OK',
    message: 'Smart Budget API is running',
    timestamp: new Date().toISOString(),
    database: mongoose.connection.readyState === 1 ? 'connected' : 'disconnected'
  });
});

// Debug middleware to log all requests
app.use((req, res, next) => {
  console.log(`📥 ${new Date().toISOString()} ${req.method} ${req.url}`);
  next();
});

// Test if routes are loaded
console.log("🔧 Auth routes object:", typeof authRoutes);
console.log("🔧 Transaction routes object:", typeof transactionRoutes);

// API routes
console.log("🔧 Mounting auth routes at /api/auth");
app.use("/api/auth", authRoutes);
console.log("🔧 Mounting transaction routes at /api/transactions");
app.use("/api/transactions", transactionRoutes);

// Add a test route to verify routing works
app.post('/api/test', (req, res) => {
  console.log('📝 Test route hit');
  res.json({ message: 'Test route working' });
});

// Error handling middleware (must be last)
app.use(errorHandler);

// Database connection with fallback options
async function connectToDatabase() {
  const connectionOptions = {
    // Removed deprecated options
  };

  // Try local MongoDB first
  try {
    await mongoose.connect(process.env.MONGO_URI, connectionOptions);
    console.log("✅ Connected to local MongoDB");
    return true;
  } catch (localErr) {
    console.log("⚠️  Local MongoDB not available, trying cloud connection...");

    // Try cloud MongoDB if local fails
    try {
      await mongoose.connect(process.env.MONGO_URI_CLOUD, connectionOptions);
      console.log("✅ Connected to cloud MongoDB");
      return true;
    } catch (cloudErr) {
      console.error("❌ All MongoDB connections failed:");
      console.error("Local:", localErr.message);
      console.error("Cloud:", cloudErr.message);
      console.log("⚠️  Starting server without database connection...");
      console.log("📝 Note: Database operations will fail until MongoDB is properly configured");
      return false;
    }
  }
}

// Start server
async function startServer() {
  const dbConnected = await connectToDatabase();

  // Force backend to use port 5000
  const port = 5000;
  console.log(`🔧 Environment PORT: ${process.env.PORT}`);
  console.log(`🔧 Forced to use port: ${port}`);

  app.listen(port, () => {
    console.log(`🚀 Smart Budget API Server running on http://localhost:${port}`);
    console.log(`📡 API Endpoints available at http://localhost:${port}/api/`);
    if (dbConnected) {
      console.log("📊 Database: Connected and ready");
    } else {
      console.log("📊 Database: Not connected (using memory store)");
    }
    console.log(`🔍 Health check: http://localhost:${port}/api/health`);
    console.log("📝 Note: This is API-only server. Frontend should run separately.");
  });
}

startServer();
