// =====================================
// UPDATED CONTROLLER (controllers/authController.js)
// =====================================
const User = require('../models/User');
const bcrypt = require('bcrypt');
const mongoose = require('mongoose');
const memoryStore = require('../utils/memoryStore');

// Check if database is connected
const isDatabaseConnected = () => {
  return mongoose.connection.readyState === 1;
};

// REGISTER - matches your frontend '/api/auth/register'
exports.registerUser = async (req, res) => {
  const { email, password } = req.body;

  // Input validation
  if (!email || !password) {
    return res.status(400).json({ 
      message: 'Email and password are required',
      error: 'MISSING_FIELDS'
    });
  }

  if (password.length < 6) {
    return res.status(400).json({ 
      message: 'Password must be at least 6 characters long',
      error: 'WEAK_PASSWORD'
    });
  }

  try {
    const saltRounds = 10;
    const hashedPassword = await bcrypt.hash(password, saltRounds);

    if (isDatabaseConnected()) {
      // Use MongoDB
      const existingUser = await User.findOne({ email });
      if (existingUser) {
        return res.status(400).json({ 
          message: 'User already exists',
          error: 'USER_EXISTS'
        });
      }

      const user = await User.create({ email, password: hashedPassword });
      res.status(201).json({
        message: 'User registered successfully',
        user: { _id: user._id, email: user.email }
      });
    } else {
      // Use memory store
      const existingUser = memoryStore.findUserByEmail(email);
      if (existingUser) {
        return res.status(400).json({ 
          message: 'User already exists',
          error: 'USER_EXISTS'
        });
      }

      const user = memoryStore.createUser({ email, password: hashedPassword });
      res.status(201).json({
        message: 'User registered successfully (using memory store)',
        user: { _id: user._id, email: user.email }
      });
    }
  } catch (err) {
    console.error('Registration error:', err);
    res.status(500).json({ 
      message: 'Something went wrong during registration',
      error: 'SERVER_ERROR'
    });
  }
};

// SIGNIN - matches your frontend '/api/auth/signin'
exports.signinUser = async (req, res) => {
  const { email, password } = req.body;

  // Input validation  
  if (!email || !password) {
    return res.status(400).json({ 
      message: 'Email and password are required',
      error: 'MISSING_FIELDS'
    });
  }

  try {
    let user;

    if (isDatabaseConnected()) {
      // Use MongoDB
      user = await User.findOne({ email });
    } else {
      // Use memory store
      user = memoryStore.findUserByEmail(email);
    }

    if (!user) {
      return res.status(401).json({ 
        message: 'Invalid credentials',
        error: 'INVALID_CREDENTIALS'
      });
    }

    // Compare the provided password with the hashed password
    const isPasswordValid = await bcrypt.compare(password, user.password);
    if (!isPasswordValid) {
      return res.status(401).json({ 
        message: 'Invalid credentials',
        error: 'INVALID_CREDENTIALS'
      });
    }

    const responseMessage = isDatabaseConnected() 
      ? 'Signed in successfully' 
      : 'Signed in successfully (using memory store)';

    res.status(200).json({
      message: responseMessage,
      user: { _id: user._id, email: user.email }
    });
  } catch (err) {
    console.error('Signin error:', err);
    res.status(500).json({ 
      message: 'Server error during sign in',
      error: 'SERVER_ERROR'
    });
  }
};

// Keep the old loginUser for backward compatibility if needed
exports.loginUser = exports.signinUser;

// =====================================
// ROUTES FILE (routes/auth.js)
// =====================================
const express = require('express');
const router = express.Router();
const authController = require('./authcontroller');

// Debug middleware to log all requests
router.use((req, res, next) => {
  console.log(`[${new Date().toISOString()}] ${req.method} ${req.originalUrl}`, req.body);
  next();
});

// POST /api/auth/register - matches your frontend
router.post('/register', authController.registerUser);

// POST /api/auth/signin - matches your frontend  
router.post('/signin', authController.signinUser);

// Alternative login route for backward compatibility
router.post('/login', authController.signinUser);

module.exports = router;

// =====================================
// MAIN SERVER FILE (server.js or app.js)
// =====================================
const express = require('express');
const cors = require('cors');
const mongoose = require('mongoose');
require('dotenv').config();

const app = express();

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Debug middleware - log all requests
app.use((req, res, next) => {
  console.log(`[${new Date().toISOString()}] "${req.method} ${req.url}" "${req.get('User-Agent')}"`);
  next();
});

// Connect to MongoDB (optional)
if (process.env.MONGODB_URI) {
  mongoose.connect(process.env.MONGODB_URI)
    .then(() => console.log('Connected to MongoDB'))
    .catch(err => {
      console.log('MongoDB connection failed, using memory store:', err.message);
    });
} else {
  console.log('No MongoDB URI provided, using memory store');
}

// Routes
const authRoutes = require('./routes/auth');
app.use('/api/auth', authRoutes);

// Health check
app.get('/health', (req, res) => {
  res.json({ 
    status: 'OK', 
    timestamp: new Date().toISOString(),
    database: mongoose.connection.readyState === 1 ? 'connected' : 'disconnected'
  });
});

// 404 handler - THIS IS CRUCIAL FOR DEBUGGING
app.use('*', (req, res) => {
  console.log(`[${new Date().toISOString()}] "${req.method} ${req.originalUrl}" Error (404): "Not found"`);
  res.status(404).json({ 
    error: 'Route not found',
    method: req.method,
    url: req.originalUrl,
    availableRoutes: [
      'POST /api/auth/register',
      'POST /api/auth/signin',
      'POST /api/auth/login',
      'GET /health'
    ]
  });
});

// Error handler
app.use((err, req, res, next) => {
  console.error('Server error:', err);
  res.status(500).json({ 
    message: 'Internal server error',
    error: process.env.NODE_ENV === 'development' ? err.message : 'Something went wrong'
  });
});

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => {
  console.log(`🚀 Server running on port ${PORT}`);
  console.log(`🔗 Available routes:`);
  console.log(`   POST http://localhost:${PORT}/api/auth/register`);
  console.log(`   POST http://localhost:${PORT}/api/auth/signin`);
  console.log(`   GET  http://localhost:${PORT}/health`);
});

// =====================================
// MEMORY STORE (utils/memoryStore.js)
// =====================================
let users = [];
let currentId = 1;

const memoryStore = {
  findUserByEmail: (email) => {
    return users.find(user => user.email === email);
  },

  createUser: (userData) => {
    const user = {
      _id: currentId++,
      email: userData.email,
      password: userData.password,
      createdAt: new Date()
    };
    users.push(user);
    return user;
  },

  getAllUsers: () => {
    return users.map(user => ({ _id: user._id, email: user.email }));
  },

  clearAll: () => {
    users = [];
    currentId = 1;
  }
};

module.exports = memoryStore;

// =====================================
// USER MODEL (models/User.js)
// =====================================
const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
  email: {
    type: String,
    required: true,
    unique: true,
    lowercase: true,
    trim: true
  },
  password: {
    type: String,
    required: true,
    minlength: 6
  }
}, {
  timestamps: true
});

module.exports = mongoose.model('User', userSchema);

// =====================================
// PACKAGE.JSON
// =====================================
/*
{
  "name": "auth-backend",
  "version": "1.0.0",
  "description": "Authentication backend with fallback memory store",
  "main": "server.js",
  "scripts": {
    "start": "node server.js",
    "dev": "nodemon server.js"
  },
  "dependencies": {
    "express": "^4.18.2",
    "mongoose": "^7.5.0",
    "bcrypt": "^5.1.0",
    "cors": "^2.8.5",
    "dotenv": "^16.3.1"
  },
  "devDependencies": {
    "nodemon": "^3.0.1"
  }
}
*/

// =====================================
// ENVIRONMENT VARIABLES (.env)
// =====================================
/*
PORT=3001
MONGODB_URI=mongodb://localhost:27017/smartbudget
NODE_ENV=development
*/