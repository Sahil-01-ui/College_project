const express = require('express');
const router = express.Router();
const Transaction = require('../models/Transaction');
const { validateTransaction } = require('../middleware/validation');
const mongoose = require('mongoose');
const memoryStore = require('../utils/memoryStore');

// Check if database is connected
const isDatabaseConnected = () => {
  return mongoose.connection.readyState === 1;
};

// Logging middleware for transaction routes
router.use((req, res, next) => {
  console.log(`💰 Transaction route: ${req.method} ${req.path}`);
  next();
});

// GET endpoint for transactions
router.get('/', async (req, res) => {
  try {
    const { userId } = req.query;

    if (!userId) {
      return res.status(400).json({ message: 'User ID is required' });
    }

    let transactions;
    if (isDatabaseConnected()) {
      transactions = await Transaction.find({ userId }).sort({ date: -1 });
    } else {
      transactions = memoryStore.findTransactionsByUserId(userId);
    }

    res.json({ transactions });
  } catch (err) {
    console.error('Error fetching transactions:', err);
    res.status(500).json({ message: 'Error fetching transactions' });
  }
});

// POST endpoint for adding a transaction
router.post('/', validateTransaction, async (req, res) => {
  try {
    const { userId, type, category, amount, description, date } = req.body;

    let transaction;
    if (isDatabaseConnected()) {
      transaction = await Transaction.create({
        userId,
        type,
        category,
        amount,
        description,
        date: date || new Date()
      });
    } else {
      transaction = memoryStore.createTransaction({
        userId,
        type,
        category,
        amount,
        description,
        date: date || new Date()
      });
    }

    const responseMessage = isDatabaseConnected()
      ? 'Transaction added successfully!'
      : 'Transaction added successfully (using memory store)!';

    res.status(201).json({
      message: responseMessage,
      transaction
    });
  } catch (err) {
    console.error('Error saving transaction:', err);
    res.status(500).json({ message: 'Error saving transaction' });
  }
});

module.exports = router;