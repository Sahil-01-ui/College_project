// =====================================
// UPDATED AUTH ROUTES (routes/auth-clean.js)
// =====================================
const express = require('express');
const router = express.Router();
const User = require('../models/User');
const bcrypt = require('bcrypt');
const mongoose = require('mongoose');
const memoryStore = require('../utils/memoryStore');

// Check if database is connected
const isDatabaseConnected = () => {
  return mongoose.connection.readyState === 1;
};

// Debug middleware for auth routes
router.use((req, res, next) => {
  console.log(`🔐 AUTH ROUTE: ${req.method} ${req.originalUrl}`);
  console.log(`📦 Body:`, req.body);
  next();
});

// Test route to verify auth routes are working
router.get('/test', (req, res) => {
  res.json({ 
    message: 'Auth routes are working!',
    endpoint: req.originalUrl,
    database: isDatabaseConnected() ? 'connected' : 'memory_store'
  });
});

// REGISTER endpoint - matches your frontend
router.post('/register', async (req, res) => {
  console.log('🎯 REGISTER endpoint hit');
  
  try {
    const { email, password } = req.body;

    // Input validation
    if (!email || !password) {
      console.log('❌ Missing email or password');
      return res.status(400).json({ 
        message: 'Email and password are required',
        error: 'MISSING_FIELDS'
      });
    }

    if (password.length < 6) {
      console.log('❌ Password too short');
      return res.status(400).json({ 
        message: 'Password must be at least 6 characters long',
        error: 'WEAK_PASSWORD'
      });
    }

    console.log(`📧 Attempting to register: ${email}`);

    const saltRounds = 10;
    const hashedPassword = await bcrypt.hash(password, saltRounds);

    if (isDatabaseConnected()) {
      console.log('💾 Using MongoDB');
      // Use MongoDB
      const existingUser = await User.findOne({ email });
      if (existingUser) {
        console.log('❌ User already exists in database');
        return res.status(400).json({ 
          message: 'User already exists',
          error: 'USER_EXISTS'
        });
      }

      const user = await User.create({ email, password: hashedPassword });
      console.log('✅ User created in database:', user._id);
      
      res.status(201).json({
        message: 'User registered successfully',
        user: { _id: user._id, email: user.email }
      });
    } else {
      console.log('🧠 Using memory store');
      // Use memory store
      const existingUser = memoryStore.findUserByEmail(email);
      if (existingUser) {
        console.log('❌ User already exists in memory');
        return res.status(400).json({ 
          message: 'User already exists',
          error: 'USER_EXISTS'
        });
      }

      const user = memoryStore.createUser({ email, password: hashedPassword });
      console.log('✅ User created in memory store:', user._id);
      
      res.status(201).json({
        message: 'User registered successfully (using memory store)',
        user: { _id: user._id, email: user.email }
      });
    }
  } catch (err) {
    console.error('💥 Registration error:', err);
    res.status(500).json({ 
      message: 'Something went wrong during registration',
      error: 'SERVER_ERROR',
      details: process.env.NODE_ENV === 'development' ? err.message : undefined
    });
  }
});

// SIGNIN endpoint - matches your frontend
router.post('/signin', async (req, res) => {
  console.log('🎯 SIGNIN endpoint hit');
  
  try {
    const { email, password } = req.body;

    // Input validation  
    if (!email || !password) {
      console.log('❌ Missing email or password');
      return res.status(400).json({ 
        message: 'Email and password are required',
        error: 'MISSING_FIELDS'
      });
    }

    console.log(`🔍 Attempting signin for: ${email}`);

    let user;

    if (isDatabaseConnected()) {
      console.log('💾 Checking MongoDB');
      // Use MongoDB
      user = await User.findOne({ email });
    } else {
      console.log('🧠 Checking memory store');
      // Use memory store
      user = memoryStore.findUserByEmail(email);
    }

    if (!user) {
      console.log('❌ User not found');
      return res.status(401).json({ 
        message: 'Invalid credentials',
        error: 'INVALID_CREDENTIALS'
      });
    }

    console.log('👤 User found, verifying password');
    // Compare the provided password with the hashed password
    const isPasswordValid = await bcrypt.compare(password, user.password);
    if (!isPasswordValid) {
      console.log('❌ Invalid password');
      return res.status(401).json({ 
        message: 'Invalid credentials',
        error: 'INVALID_CREDENTIALS'
      });
    }

    const responseMessage = isDatabaseConnected() 
      ? 'Signed in successfully' 
      : 'Signed in successfully (using memory store)';

    console.log('✅ Signin successful');

    res.status(200).json({
      message: responseMessage,
      user: { _id: user._id, email: user.email }
    });
  } catch (err) {
    console.error('💥 Signin error:', err);
    res.status(500).json({ 
      message: 'Server error during sign in',
      error: 'SERVER_ERROR',
      details: process.env.NODE_ENV === 'development' ? err.message : undefined
    });
  }
});

// LOGIN endpoint for backward compatibility
router.post('/login', async (req, res) => {
  console.log('🎯 LOGIN endpoint hit (redirecting to signin logic)');
  // Reuse signin logic
  req.url = '/signin';
  return router.handle(req, res);
});

module.exports = router;