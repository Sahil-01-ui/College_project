// Auth routes for Smart Budget API
const express = require('express');
const router = express.Router();

// Import controllers
const { registerUser, loginUser } = require('../controllers/authController ');

// Optional: Import validation middleware if you have it
// const { validateUserRegistration, validateUserLogin } = require('../middleware/validation');

// Logging middleware for auth routes
router.use((req, res, next) => {
  console.log(`🔐 Auth route: ${req.method} ${req.path}`);
  next();
});

// Auth routes
// If you have validation middleware, put it before the controllers
// router.post('/register', validateUserRegistration, registerUser);
// router.post('/signin', validateUserLogin, loginUser);

router.post('/register', registerUser);
router.post('/signin', loginUser);

// Export the router
module.exports = router;
app.use("/api/auth", authRoutes);
