// Smart Budget Backend on Port 5001 (to avoid conflicts)
const express = require("express");
const cors = require("cors");

console.log('🚀 Starting Smart Budget Backend on Port 5001...');

const app = express();

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Log all requests
app.use((req, res, next) => {
  console.log(`📥 ${new Date().toISOString()} ${req.method} ${req.url}`);
  next();
});

// Health check
app.get('/api/health', (req, res) => {
  res.json({
    status: 'OK',
    message: 'Smart Budget API is running on port 5001',
    timestamp: new Date().toISOString(),
    port: 5001
  });
});

// Auth routes
app.post('/api/auth/register', (req, res) => {
  console.log('📝 Register request:', req.body);
  res.status(201).json({
    message: 'User registered successfully (test mode)',
    user: { _id: 'test123', email: req.body.email }
  });
});

app.post('/api/auth/signin', (req, res) => {
  console.log('📝 Signin request:', req.body);
  res.json({
    message: 'Login successful (test mode)',
    user: { _id: 'test123', email: req.body.email }
  });
});

// Transaction routes
app.get('/api/transactions', (req, res) => {
  console.log('📝 Get transactions:', req.query);
  res.json({
    transactions: [
      {
        _id: 'tx1',
        description: 'Sample Transaction',
        category: 'food',
        amount: 50,
        type: 'expense',
        date: new Date().toISOString()
      }
    ]
  });
});

app.post('/api/transactions', (req, res) => {
  console.log('📝 Create transaction:', req.body);
  res.status(201).json({
    message: 'Transaction added successfully (test mode)',
    transaction: {
      _id: 'tx' + Date.now(),
      ...req.body,
      date: req.body.date || new Date().toISOString()
    }
  });
});

// Use port 5001 to avoid conflicts
const PORT = 5001;

const server = app.listen(PORT, () => {
  console.log(`✅ Smart Budget Backend running on http://localhost:${PORT}`);
  console.log(`🔍 Health check: http://localhost:${PORT}/api/health`);
  console.log(`📡 API endpoints:`);
  console.log(`   POST http://localhost:${PORT}/api/auth/register`);
  console.log(`   POST http://localhost:${PORT}/api/auth/signin`);
  console.log(`   GET  http://localhost:${PORT}/api/transactions`);
  console.log(`   POST http://localhost:${PORT}/api/transactions`);
  console.log('🎉 Server started successfully on port 5001!');
});

// Handle server errors
server.on('error', (error) => {
  if (error.code === 'EADDRINUSE') {
    console.error(`❌ Port ${PORT} is already in use!`);
    console.log('💡 Try these solutions:');
    console.log('   1. Kill all Node processes: taskkill /F /IM node.exe');
    console.log('   2. Use a different port');
    console.log('   3. Check what\'s using the port: netstat -ano | findstr :5001');
    process.exit(1);
  } else {
    console.error('❌ Server error:', error);
    process.exit(1);
  }
});

// Graceful shutdown
process.on('SIGINT', () => {
  console.log('\n🛑 Shutting down server...');
  server.close(() => {
    console.log('✅ Server closed');
    process.exit(0);
  });
});

process.on('SIGTERM', () => {
  console.log('\n🛑 Shutting down server...');
  server.close(() => {
    console.log('✅ Server closed');
    process.exit(0);
  });
});
