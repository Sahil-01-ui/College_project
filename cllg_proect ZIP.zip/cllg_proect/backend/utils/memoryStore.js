// In-memory storage fallback when database is not available
class MemoryStore {
  constructor() {
    this.users = new Map();
    this.transactions = new Map();
    this.userIdCounter = 1;
    this.transactionIdCounter = 1;
  }

  // User methods
  createUser(userData) {
    const userId = `user_${this.userIdCounter++}`;
    const user = {
      _id: userId,
      ...userData,
      createdAt: new Date()
    };
    this.users.set(userId, user);
    return user;
  }

  findUserByEmail(email) {
    for (const user of this.users.values()) {
      if (user.email === email) {
        return user;
      }
    }
    return null;
  }

  findUserById(id) {
    return this.users.get(id) || null;
  }

  // Transaction methods
  createTransaction(transactionData) {
    const transactionId = `tx_${this.transactionIdCounter++}`;
    const transaction = {
      _id: transactionId,
      ...transactionData,
      createdAt: new Date()
    };
    this.transactions.set(transactionId, transaction);
    return transaction;
  }

  findTransactionsByUserId(userId) {
    const userTransactions = [];
    for (const transaction of this.transactions.values()) {
      if (transaction.userId === userId) {
        userTransactions.push(transaction);
      }
    }
    return userTransactions.sort((a, b) => new Date(b.date) - new Date(a.date));
  }

  // Clear all data
  clear() {
    this.users.clear();
    this.transactions.clear();
    this.userIdCounter = 1;
    this.transactionIdCounter = 1;
  }

  // Get stats
  getStats() {
    return {
      users: this.users.size,
      transactions: this.transactions.size
    };
  }
}

// Export singleton instance
module.exports = new MemoryStore();
