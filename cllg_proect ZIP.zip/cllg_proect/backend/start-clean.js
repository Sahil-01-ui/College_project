// Clean startup script for Smart Budget Backend
const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const path = require("path");

// Load environment variables
require("dotenv").config({ path: path.join(__dirname, '.env') });

console.log('🚀 Starting Smart Budget Backend...');
console.log(`📁 Working directory: ${__dirname}`);
console.log(`🔧 NODE_ENV: ${process.env.NODE_ENV}`);
console.log(`🔧 Environment PORT: ${process.env.PORT}`);

const app = express();

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Simple health check
app.get('/api/health', (req, res) => {
  res.json({
    status: 'OK',
    message: 'Smart Budget API is running',
    timestamp: new Date().toISOString(),
    port: 5000
  });
});

// Test auth route
app.post('/api/auth/register', (req, res) => {
  console.log('📝 Register request received:', req.body);
  res.json({
    message: 'Test register endpoint working',
    data: req.body
  });
});

app.post('/api/auth/signin', (req, res) => {
  console.log('📝 Signin request received:', req.body);
  res.json({
    message: 'Test signin endpoint working',
    data: req.body
  });
});

// Test transaction route
app.get('/api/transactions', (req, res) => {
  console.log('📝 Transactions request received:', req.query);
  res.json({
    message: 'Test transactions endpoint working',
    transactions: []
  });
});

// Force port 5000
const PORT = 5000;

app.listen(PORT, () => {
  console.log(`✅ Smart Budget Backend running on http://localhost:${PORT}`);
  console.log(`🔍 Health check: http://localhost:${PORT}/api/health`);
  console.log(`📡 API endpoints:`);
  console.log(`   POST http://localhost:${PORT}/api/auth/register`);
  console.log(`   POST http://localhost:${PORT}/api/auth/signin`);
  console.log(`   GET  http://localhost:${PORT}/api/transactions`);
  console.log('🎉 Server started successfully!');
});

// Handle errors
process.on('uncaughtException', (error) => {
  console.error('❌ Uncaught Exception:', error);
  process.exit(1);
});

process.on('unhandledRejection', (error) => {
  console.error('❌ Unhandled Rejection:', error);
  process.exit(1);
});
