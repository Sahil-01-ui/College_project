// Test script to verify backend routes are working
const http = require('http');

function makeRequest(method, path, data = null) {
  return new Promise((resolve, reject) => {
    const options = {
      hostname: 'localhost',
      port: 5000,
      path: path,
      method: method,
      headers: {
        'Content-Type': 'application/json',
      }
    };

    console.log(`\n🧪 Testing: ${method} ${path}`);

    const req = http.request(options, (res) => {
      let responseData = '';
      
      res.on('data', (chunk) => {
        responseData += chunk;
      });
      
      res.on('end', () => {
        console.log(`📊 Status: ${res.statusCode} ${res.statusMessage}`);
        console.log(`📄 Response: ${responseData}`);
        
        resolve({
          status: res.statusCode,
          statusMessage: res.statusMessage,
          data: responseData,
          headers: res.headers
        });
      });
    });

    req.on('error', (error) => {
      console.log(`❌ Request Error: ${error.message}`);
      reject(error);
    });

    if (data) {
      req.write(JSON.stringify(data));
    }
    
    req.end();
  });
}

async function testRoutes() {
  console.log('🔍 Testing Smart Budget Backend Routes...\n');

  try {
    // Test 1: Health check
    console.log('='.repeat(50));
    console.log('TEST 1: Health Check');
    console.log('='.repeat(50));
    await makeRequest('GET', '/api/health');

    // Test 2: Auth routes exist
    console.log('\n' + '='.repeat(50));
    console.log('TEST 2: Auth Routes');
    console.log('='.repeat(50));
    
    // Test register endpoint
    await makeRequest('POST', '/api/auth/register', {
      email: `test${Date.now()}@example.com`,
      password: 'testpassword123'
    });

    // Test signin endpoint
    await makeRequest('POST', '/api/auth/signin', {
      email: 'nonexistent@example.com',
      password: 'wrongpassword'
    });

    // Test 3: Transaction routes
    console.log('\n' + '='.repeat(50));
    console.log('TEST 3: Transaction Routes');
    console.log('='.repeat(50));
    
    await makeRequest('GET', '/api/transactions?userId=test123');

    // Test 4: Non-existent routes
    console.log('\n' + '='.repeat(50));
    console.log('TEST 4: Non-existent Routes');
    console.log('='.repeat(50));
    
    await makeRequest('GET', '/api/nonexistent');
    await makeRequest('POST', '/api/auth/nonexistent');

  } catch (error) {
    console.error('❌ Test failed:', error.message);
  }

  console.log('\n🎉 Route testing completed!');
  console.log('\n📝 Analysis:');
  console.log('- If you see 404 errors for /api/auth/register, the auth routes are not loading');
  console.log('- If you see 200/201/400/401 responses, the routes are working');
  console.log('- Check the backend console for route mounting messages');
}

// Run the tests
testRoutes().catch(console.error);
