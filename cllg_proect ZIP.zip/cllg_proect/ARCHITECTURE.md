# Smart Budget - Architecture Documentation

## 🏗️ Separation of Concerns

This document outlines the proper architectural separation implemented in the Smart Budget application.

## 📊 Architecture Overview

```
┌─────────────────┐    HTTP API     ┌─────────────────┐    Database     ┌─────────────────┐
│                 │    Requests     │                 │    Operations   │                 │
│    Frontend     │◄───────────────►│     Backend     │◄───────────────►│    MongoDB      │
│   (Port 3000)   │                 │   (Port 5000)   │                 │   (Port 27017)  │
│                 │                 │                 │                 │                 │
└─────────────────┘                 └─────────────────┘                 └─────────────────┘
```

## 🎯 Backend Responsibilities (API Server)

### ✅ What Backend DOES Handle:
- **Database Connections**: MongoDB connection management
- **Business Logic**: User authentication, transaction processing
- **API Endpoints**: RESTful API for all operations
- **Data Validation**: Server-side input validation
- **Security**: Password hashing, authentication
- **Error Handling**: Comprehensive error management
- **Memory Store Fallback**: In-memory storage when DB unavailable

### ❌ What Backend DOES NOT Handle:
- Static file serving (HTML, CSS, JS)
- Frontend routing
- UI rendering
- Client-side interactions

### 📡 API Endpoints:
```
GET  /api/health                 - Health check
POST /api/auth/register          - User registration
POST /api/auth/signin            - User login
GET  /api/transactions           - Get user transactions
POST /api/transactions           - Create new transaction
```

## 🎨 Frontend Responsibilities (Web Client)

### ✅ What Frontend DOES Handle:
- **User Interface**: HTML, CSS, JavaScript
- **User Interactions**: Form handling, navigation
- **API Communication**: HTTP requests to backend
- **Client-side Routing**: Page navigation
- **Local Storage**: User session management
- **UI State Management**: Form states, loading indicators

### ❌ What Frontend DOES NOT Handle:
- Database operations
- Business logic
- Data validation (relies on backend)
- Authentication logic (only UI)

### 🔗 API Communication:
```javascript
// Configuration-based API calls
const response = await fetch(getApiUrl('/api/auth/signin'), {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ email, password })
});
```

## 🚀 Independent Deployment

### Backend Deployment:
```bash
cd backend
npm install
npm start
# Runs on http://localhost:5000
```

### Frontend Deployment:
```bash
cd frontend
npm install
npm start
# Runs on http://localhost:3000
```

## 🔧 Configuration Management

### Backend Configuration (`backend/.env`):
```env
MONGO_URI=mongodb://localhost:27017/smartbudget
MONGO_URI_CLOUD=mongodb+srv://...
PORT=5000
NODE_ENV=development
```

### Frontend Configuration (`frontend/config.js`):
```javascript
const config = {
  API_BASE_URL: window.location.hostname === 'localhost' 
    ? 'http://localhost:5000' 
    : '',
  ENDPOINTS: {
    AUTH: {
      REGISTER: '/api/auth/register',
      LOGIN: '/api/auth/signin'
    }
  }
};
```

## 🧪 Testing Strategy

### 1. Backend Testing (Independent):
```bash
# Start backend only
cd backend && npm start

# Test API endpoints
curl http://localhost:5000/api/health
curl -X POST http://localhost:5000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"email":"test@example.com","password":"password123"}'
```

### 2. Frontend Testing (Independent):
```bash
# Start frontend only
cd frontend && npm start

# Access at http://localhost:3000
# Should show UI but API calls will fail without backend
```

### 3. Integration Testing:
```bash
# Start both servers
cd backend && npm start &
cd frontend && npm start

# Test complete user flow:
# 1. Register user via frontend
# 2. Verify API call in browser dev tools
# 3. Check backend logs for request
# 4. Verify database operation
```

## 🔒 Security Considerations

### Backend Security:
- **Password Hashing**: bcrypt with salt rounds
- **Input Validation**: Server-side validation middleware
- **CORS Configuration**: Proper cross-origin setup
- **Error Handling**: No sensitive data in error responses

### Frontend Security:
- **No Sensitive Data**: No database credentials or secrets
- **API Communication**: All sensitive operations via backend
- **Local Storage**: Only non-sensitive user data

## 📈 Benefits of This Architecture

### 1. **Scalability**:
- Backend can serve multiple frontend clients
- Independent scaling of frontend and backend
- API can be used by mobile apps, other services

### 2. **Maintainability**:
- Clear separation of concerns
- Independent development and testing
- Easier debugging and troubleshooting

### 3. **Deployment Flexibility**:
- Deploy frontend and backend separately
- Use different hosting providers
- Independent version control and releases

### 4. **Development Workflow**:
- Frontend and backend teams can work independently
- API-first development approach
- Easy to add new frontend clients

## 🚨 Common Anti-Patterns Avoided

### ❌ What We DON'T Do:
- **Mixed Concerns**: Backend serving static files
- **Tight Coupling**: Frontend directly accessing database
- **Hardcoded URLs**: Using localhost URLs in production
- **Single Server**: Everything running on one port

### ✅ What We DO:
- **Clean Separation**: Each component has single responsibility
- **Loose Coupling**: Communication only via HTTP API
- **Configuration-Driven**: Environment-specific settings
- **Independent Services**: Each can run and be tested alone

## 📝 Next Steps

1. **Add Authentication Middleware**: JWT tokens for API security
2. **API Versioning**: Version API endpoints for backward compatibility
3. **Error Logging**: Centralized logging for backend
4. **Performance Monitoring**: API response time monitoring
5. **Automated Testing**: Unit and integration test suites
