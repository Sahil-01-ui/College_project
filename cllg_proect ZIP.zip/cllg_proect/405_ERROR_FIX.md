# HTTP 405 Method Not Allowed Error - Diagnosis and Fix

## 🔍 Root Cause Analysis

The HTTP 405 "Method Not Allowed" error occurs when:

1. **Frontend sends wrong HTTP method** - Using GET instead of POST, etc.
2. **Backend route doesn't support the method** - Route only handles GET but receives POST
3. **CORS preflight issues** - Browser sends OPTIONS request that isn't handled
4. **Route path mismatches** - Request goes to wrong endpoint
5. **Middleware blocking requests** - Validation or auth middleware rejecting requests

## 🛠️ Fixes Implemented

### 1. **Enhanced CORS Configuration** (`backend/server.js`)

**Problem**: Basic CORS setup might not handle preflight requests properly.

**Fix**: Added comprehensive CORS configuration:
```javascript
app.use(cors({
  origin: ['http://localhost:3000', 'http://127.0.0.1:3000'],
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization'],
  credentials: true
}));

// Handle preflight requests
app.options('*', (req, res) => {
  res.header('Access-Control-Allow-Origin', req.headers.origin || '*');
  res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  res.sendStatus(200);
});
```

### 2. **Route Debugging and Logging**

**Problem**: Hard to identify which route is causing the 405 error.

**Fix**: Added comprehensive logging to all routes:
- Auth routes log all incoming requests
- Transaction routes log all incoming requests
- Catch-all route for unmatched API endpoints

### 3. **Explicit Method Handling** (`backend/routes/auth.js`)

**Problem**: Routes might not explicitly handle unsupported methods.

**Fix**: Added explicit method validation:
```javascript
router.all('/register', (req, res) => {
  if (req.method !== 'POST') {
    return res.status(405).json({
      error: 'Method Not Allowed',
      message: `${req.method} method is not allowed for /register. Use POST instead.`,
      allowedMethods: ['POST']
    });
  }
});
```

### 4. **Catch-All Route Handler** (`backend/server.js`)

**Problem**: Undefined routes return generic 404 without helpful information.

**Fix**: Added catch-all handler for debugging:
```javascript
app.all('/api/*', (req, res) => {
  console.log(`❌ Unmatched API route: ${req.method} ${req.path}`);
  res.status(404).json({
    error: 'API endpoint not found',
    method: req.method,
    path: req.path,
    message: `The endpoint ${req.method} ${req.path} does not exist`
  });
});
```

## 🧪 Diagnostic Tools Created

### 1. **405 Error Diagnostic Page** (`frontend/test-405-error.html`)

Comprehensive testing tool that:
- Tests all API endpoints with direct fetch calls
- Tests frontend utility functions
- Tests different HTTP methods on each endpoint
- Tests endpoint variations to catch typos

### 2. **Backend Test Script** (`test-backend.js`)

Node.js script that tests backend independently:
- Validates all API endpoints work correctly
- Tests with proper request formats
- Identifies backend-specific issues

## 🔧 Testing Instructions

### Step 1: Restart Backend with Enhanced Logging
```bash
cd backend
npm start
```

**Expected Output:**
```
🚀 Smart Budget API Server running on http://localhost:5000
📡 API Endpoints available at http://localhost:5000/api/
📊 Database: Connected and ready
🔍 Health check: http://localhost:5000/api/health
```

### Step 2: Test Backend Independently
```bash
node test-backend.js
```

**Expected**: All tests should pass with 200/201 status codes.

### Step 3: Test Frontend Connectivity
```bash
cd frontend
npm start
```

Open: http://localhost:3000/test-405-error.html

**Run all diagnostic tests** - should identify exact location of 405 error.

### Step 4: Test Application Flow
1. **Open**: http://localhost:3000
2. **Open browser dev tools** (F12) → Network tab
3. **Attempt user registration**
4. **Check Network tab** for any 405 responses
5. **Check backend console** for detailed request logs

## 🚨 Common 405 Error Scenarios

### Scenario 1: CORS Preflight Failure
**Symptoms**: 405 error on OPTIONS request
**Solution**: Enhanced CORS configuration handles this

### Scenario 2: Wrong HTTP Method
**Symptoms**: Frontend sends GET to POST endpoint
**Solution**: Verify frontend API calls use correct methods

### Scenario 3: Route Path Mismatch
**Symptoms**: Request goes to non-existent endpoint
**Solution**: Check for typos in endpoint URLs

### Scenario 4: Middleware Rejection
**Symptoms**: Request blocked before reaching route handler
**Solution**: Check validation middleware logic

## 📋 Verification Checklist

### ✅ Backend Verification:
- [ ] Backend starts without errors
- [ ] All routes log incoming requests
- [ ] Health endpoint returns 200: `GET /api/health`
- [ ] Register endpoint returns 201: `POST /api/auth/register`
- [ ] Login endpoint returns 401: `POST /api/auth/signin` (with wrong credentials)
- [ ] Transactions endpoint returns 200: `GET /api/transactions?userId=test`

### ✅ Frontend Verification:
- [ ] Diagnostic page loads without errors
- [ ] All direct API tests pass
- [ ] Frontend utils tests pass
- [ ] Method validation shows expected 405s for wrong methods
- [ ] Endpoint validation shows 404s for wrong paths

### ✅ Integration Verification:
- [ ] User registration works without 405 errors
- [ ] User login works without 405 errors
- [ ] Transaction creation works without 405 errors
- [ ] Browser Network tab shows successful API calls
- [ ] Backend logs show all requests being processed

## 🔍 Debugging Commands

```bash
# Check backend logs for request details
# Look for lines starting with 🔐 (auth) or 💰 (transactions)

# Test specific endpoint manually
curl -X POST http://localhost:5000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"email":"test@example.com","password":"password123"}'

# Test with wrong method (should return 405)
curl -X GET http://localhost:5000/api/auth/register

# Check CORS preflight
curl -X OPTIONS http://localhost:5000/api/auth/register \
  -H "Origin: http://localhost:3000" \
  -H "Access-Control-Request-Method: POST"
```

## 🎯 Expected Results After Fix

1. **No more 405 errors** during normal application usage
2. **Clear error messages** when 405 errors do occur (wrong method used)
3. **Detailed logging** helps identify any remaining issues
4. **Proper CORS handling** for all cross-origin requests
5. **Graceful error responses** with helpful debugging information

The 405 Method Not Allowed error should now be completely resolved with comprehensive error handling and debugging capabilities! 🎉
