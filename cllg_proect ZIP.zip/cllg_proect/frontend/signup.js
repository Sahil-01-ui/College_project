document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('signupForm');
  const message = document.getElementById('message');

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const email = document.getElementById('email').value.trim();
    const password = document.getElementById('password').value.trim();

    try {
      const data = await makeApiCall('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' }, // ✅ add headers
        body: JSON.stringify({ email, password })
      });

      message.style.color = 'green';
      message.textContent = 'Signup successful! Redirecting...';
      setTimeout(() => {
        window.location.href = 'signin.html';
      }, 1500);
    } catch (err) {
      const userMessage = showApiError(err, 'Signup failed. Please try again.');
      message.style.color = 'red';
      message.textContent = userMessage;
    }
  });
});
