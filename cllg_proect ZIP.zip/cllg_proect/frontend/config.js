// Frontend configuration for different environments
const config = {
  // API base URL - change this based on your environment
  API_BASE_URL: (['localhost', '127.0.0.1', '::1'].includes(window.location.hostname))
    ? 'http://localhost:5000'
    : '', // Use relative URLs in production
  
  // API endpoints
  ENDPOINTS: {
    HEALTH: '/api/health',
    AUTH: {
      REGISTER: '/api/auth/register',
      LOGIN: '/api/auth/signin'
    },
    TRANSACTIONS: {
      LIST: '/api/transactions',
      CREATE: '/api/transactions'
    }
  },

  // Local storage keys
  STORAGE_KEYS: {
    USER: 'smartBudgetUser'
  },

  // UI configuration
  UI: {
    TOAST_DURATION: 3000,
    REDIRECT_DELAY: 1500
  }
};

// Helper function to get full API URL
function getApiUrl(endpoint) {
  return config.API_BASE_URL + endpoint;
}

// Export for use in other scripts
window.SmartBudgetConfig = config;
window.getApiUrl = getApiUrl;
