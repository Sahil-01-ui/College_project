document.addEventListener('DOMContentLoaded', function () {
    const signinForm = document.getElementById('signinForm');
    const signinBtn = document.getElementById('signinBtn');
    const emailInput = document.getElementById('email');
    const passwordInput = document.getElementById('password');

    signinForm.addEventListener('submit', async function (e) {
        e.preventDefault();

        const email = emailInput.value.trim();
        const password = passwordInput.value.trim();

        if (!email || !password) {
            showToast('Missing Information', 'Please fill in all fields.', 'error');
            return;
        }

        signinBtn.innerHTML = 'Signing In...';
        signinBtn.disabled = true;

        try {
            const data = await makeApiCall('/api/auth/signin', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ email, password })
            });

            // Save user to localStorage
            localStorage.setItem("smartBudgetUser", JSON.stringify(data.user));

            showToast('Success', 'Signed in successfully!', 'success');
            setTimeout(() => {
                window.location.href = 'dashboard.html';
            }, 1500);
        } catch (err) {
            const userMessage = showApiError(err, 'Sign in failed. Please try again.');
            showToast('Error', userMessage, 'error');
            signinBtn.innerHTML = 'Sign In';
            signinBtn.disabled = false;
        }
    });

    function showToast(title, message, type = 'success') {
        let toastContainer = document.querySelector('.toast-container');
        if (!toastContainer) {
            toastContainer = document.createElement('div');
            toastContainer.className = 'toast-container';
            toastContainer.style.position = 'fixed';
            toastContainer.style.top = '20px';
            toastContainer.style.right = '20px';
            toastContainer.style.zIndex = '10000';
            document.body.appendChild(toastContainer);
        }

        const toast = document.createElement('div');
        toast.className = `toast ${type}`;
        toast.style.padding = '12px';
        toast.style.marginTop = '10px';
        toast.style.borderRadius = '5px';
        toast.style.backgroundColor = type === 'success' ? '#4caf50' : '#f44336';
        toast.style.color = 'white';
        toast.innerHTML = `<strong>${title}</strong><br>${message}`;
        toastContainer.appendChild(toast);

        setTimeout(() => {
            toast.style.opacity = '0';
            setTimeout(() => toast.remove(), 500);
        }, 3000);
    }
});
