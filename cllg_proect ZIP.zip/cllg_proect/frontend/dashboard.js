document.addEventListener('DOMContentLoaded', () => {
  const user = JSON.parse(localStorage.getItem(SmartBudgetConfig.STORAGE_KEYS.USER));
  if (!user) return window.location.href = 'signin.html';

  const transactionsList = document.getElementById('transactionsList');
  const transactionForm = document.getElementById('transactionForm');
  const addTransactionBtn = document.getElementById('addTransactionBtn');
  const cancelBtn = document.getElementById('cancelBtn');

  document.getElementById('userName').textContent = user.email || "User";

  // Show form
  addTransactionBtn.addEventListener('click', () => {
    transactionForm.style.display = 'block';
  });

  // Hide form
  cancelBtn.addEventListener('click', () => {
    transactionForm.style.display = 'none';
  });

  // Load transactions from backend
  async function loadTransactions() {
    try {
      const data = await makeApiCall(`/api/transactions?userId=${user._id}`, {
        method: 'GET'
      });
      const transactions = data.transactions || [];

      transactionsList.innerHTML = '';
      transactions.forEach(tx => {
        const div = document.createElement('div');
        div.className = 'transaction-item';
        div.innerHTML = `
          <div><strong>${tx.description}</strong></div>
          <div>Category: ${tx.category}</div>
          <div>${tx.type === 'income' ? '+' : '-'} ₹${tx.amount}</div>
          <div>${new Date(tx.date).toLocaleDateString()}</div>
        `;
        transactionsList.appendChild(div);
      });

        // --- Overview cards calculations ---
        try {
          const amounts = (transactions || []).map(tx => ({
            type: tx.type,
            amount: Number(tx.amount) || 0,
            date: new Date(tx.date)
          }));

          // Total balance = all income - all expenses (independent of month)
          const totalIncomeAll = amounts.filter(a => a.type === 'income').reduce((sum, a) => sum + a.amount, 0);
          const totalExpensesAll = amounts.filter(a => a.type === 'expense').reduce((sum, a) => sum + a.amount, 0);
          const totalBalance = totalIncomeAll - totalExpensesAll;

          // This month totals
          const now = new Date();
          const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);
          const nextMonthStart = new Date(now.getFullYear(), now.getMonth() + 1, 1);
          const thisMonth = amounts.filter(a => a.date >= monthStart && a.date < nextMonthStart);
          const thisMonthIncome = thisMonth.filter(a => a.type === 'income').reduce((sum, a) => sum + a.amount, 0);
          const thisMonthExpenses = thisMonth.filter(a => a.type === 'expense').reduce((sum, a) => sum + a.amount, 0);

          // Update DOM
          const fmt = n => `₹${(Number(n) || 0).toFixed(2)}`;
          document.getElementById('totalBalance').textContent = fmt(totalBalance);
          document.getElementById('totalIncome').textContent = fmt(thisMonthIncome);
          document.getElementById('totalExpenses').textContent = fmt(thisMonthExpenses);
          const statusEl = document.getElementById('balanceStatus');
          if (statusEl) {
            statusEl.textContent = totalBalance >= 0 ? 'Positive balance' : 'Negative balance';
          }
        } catch (calcErr) {
          console.error('Failed to compute overview totals:', calcErr);
        }

    } catch (err) {
      const userMessage = showApiError(err, 'Failed to load transactions.');
      alert('❌ ' + userMessage);
    }
  }

  // Add transaction
  transactionForm.addEventListener('submit', async (e) => {
    e.preventDefault();

    const payload = {
      userId: user._id,
      type: document.getElementById('transactionType').value,
      category: document.getElementById('category').value,
      amount: parseFloat(document.getElementById('amount').value),
      description: document.getElementById('description').value,
      date: document.getElementById('date').value || new Date().toISOString()
    };

    try {
      const data = await makeApiCall('/api/transactions', {
        method: 'POST',
        body: JSON.stringify(payload)
      });

      transactionForm.reset();
      transactionForm.style.display = 'none';
      loadTransactions();
    } catch (err) {
      const userMessage = showApiError(err, 'Failed to save transaction. Please try again.');
      alert('❌ ' + userMessage);
    }
  });

  // Logout
  document.getElementById('logoutBtn').addEventListener('click', () => {
    localStorage.removeItem(SmartBudgetConfig.STORAGE_KEYS.USER);
    window.location.href = 'signin.html';
  });

  loadTransactions();
});
