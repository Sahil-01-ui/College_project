// API utility functions with robust error handling

/**
 * Makes an API call with proper error handling and JSON parsing
 * @param {string} endpoint - API endpoint (e.g., '/api/auth/signin')
 * @param {object} options - Fetch options (method, headers, body, etc.)
 * @returns {Promise<object>} - Parsed JSON response
 */
async function makeApiCall(endpoint, options = {}) {
  try {
    console.log(`Making API call to: ${endpoint}`);
    console.log('Options:', options);

    // Check if backend is reachable first
    const apiUrl = getApiUrl(endpoint);
    console.log('Full API URL:', apiUrl);

    // Make the request
    const response = await fetch(apiUrl, {
      method: 'GET', // Default to GET if no method specified
      ...options,
      headers: {
        'Content-Type': 'application/json',
        ...options.headers
      }
    });

    console.log(`Response status: ${response.status} ${response.statusText}`);
    console.log('Response headers:', Object.fromEntries(response.headers.entries()));

    // Check if the response is JSON
    const contentType = response.headers.get('content-type');
    if (!contentType || !contentType.includes('application/json')) {
      const textResponse = await response.text();
      console.error('Non-JSON response received:', textResponse);
      
      // Check if it's an HTML error page
      if (textResponse.includes('<html>') || textResponse.includes('<!DOCTYPE')) {
        throw new Error(`Server error: Received HTML page instead of JSON. This usually means the backend server is not running or there's a routing issue.`);
      }
      
      throw new Error(`Server returned non-JSON response (${response.status}): ${textResponse.substring(0, 200)}...`);
    }

    // Get the response text
    const responseText = await response.text();
    console.log('Response text:', responseText);

    // Check if response is empty
    if (!responseText.trim()) {
      throw new Error(`Server returned empty response (${response.status})`);
    }

    // Parse JSON safely
    let data;
    try {
      data = JSON.parse(responseText);
    } catch (jsonError) {
      console.error('JSON parsing error:', jsonError);
      console.error('Response text that failed to parse:', responseText);
      throw new Error(`Invalid JSON response from server: ${jsonError.message}`);
    }

    // Check if the request was successful
    if (!response.ok) {
      const errorMessage = data.message || data.error || `Request failed with status ${response.status}`;

      // Provide specific guidance for 405 errors
      if (response.status === 405) {
        throw new Error(`Method Not Allowed (405): The ${options.method || 'GET'} method is not supported for ${endpoint}. ${errorMessage}`);
      }

      throw new Error(errorMessage);
    }

    console.log('Successful API response:', data);
    return data;

  } catch (error) {
    console.error(`API call failed for ${endpoint}:`, error);
    
    // Enhance error messages for common issues
    if (error.name === 'TypeError' && error.message.includes('fetch')) {
      throw new Error('Cannot connect to backend server. Please ensure the backend is running on http://localhost:5000');
    }
    
    if (error.name === 'TypeError' && error.message.includes('NetworkError')) {
      throw new Error('Network error: Cannot reach the backend server. Check if it\'s running and accessible.');
    }

    // Re-throw the error with additional context
    throw error;
  }
}

/**
 * Check if the backend API is reachable
 * @returns {Promise<boolean>} - True if backend is reachable
 */
async function checkBackendHealth() {
  try {
    const data = await makeApiCall('/api/health');
    return data.status === 'OK';
  } catch (error) {
    console.error('Backend health check failed:', error);
    return false;
  }
}

/**
 * Show user-friendly error messages
 * @param {Error} error - The error to display
 * @param {string} fallbackMessage - Fallback message if error is unclear
 */
function showApiError(error, fallbackMessage = 'An unexpected error occurred') {
  let userMessage = fallbackMessage;
  
  if (error.message.includes('Cannot connect to backend')) {
    userMessage = 'Cannot connect to server. Please try again later.';
  } else if (error.message.includes('Invalid JSON')) {
    userMessage = 'Server response error. Please try again.';
  } else if (error.message.includes('Server returned empty')) {
    userMessage = 'Server error. Please try again later.';
  } else if (error.message) {
    userMessage = error.message;
  }
  
  console.error('API Error:', error);
  return userMessage;
}

// Export functions to global scope
window.makeApiCall = makeApiCall;
window.checkBackendHealth = checkBackendHealth;
window.showApiError = showApiError;
