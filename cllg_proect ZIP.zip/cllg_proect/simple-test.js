// Simple test to check if backend routes are working
const fetch = require('node-fetch');

async function testBackend() {
  console.log('🧪 Testing Smart Budget Backend...\n');

  try {
    // Test 1: Health check
    console.log('1. Testing health endpoint...');
    const healthResponse = await fetch('http://localhost:5000/api/health');
    console.log(`   Status: ${healthResponse.status}`);
    const healthData = await healthResponse.text();
    console.log(`   Response: ${healthData.substring(0, 100)}...\n`);

    // Test 2: Register endpoint
    console.log('2. Testing register endpoint...');
    const registerResponse = await fetch('http://localhost:5000/api/auth/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        email: `test${Date.now()}@example.com`,
        password: 'testpassword123'
      })
    });
    console.log(`   Status: ${registerResponse.status}`);
    const registerData = await registerResponse.text();
    console.log(`   Response: ${registerData.substring(0, 100)}...\n`);

    // Test 3: Login endpoint
    console.log('3. Testing login endpoint...');
    const loginResponse = await fetch('http://localhost:5000/api/auth/signin', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        email: 'test@example.com',
        password: 'wrongpassword'
      })
    });
    console.log(`   Status: ${loginResponse.status}`);
    const loginData = await loginResponse.text();
    console.log(`   Response: ${loginData.substring(0, 100)}...\n`);

  } catch (error) {
    console.error('❌ Error:', error.message);
  }
}

testBackend();
