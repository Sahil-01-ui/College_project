// Simple script to test if the backend is working
const http = require('http');

function testEndpoint(path, method = 'GET', data = null) {
  return new Promise((resolve, reject) => {
    const options = {
      hostname: 'localhost',
      port: 5000,
      path: path,
      method: method,
      headers: {
        'Content-Type': 'application/json',
      }
    };

    const req = http.request(options, (res) => {
      let responseData = '';
      
      res.on('data', (chunk) => {
        responseData += chunk;
      });
      
      res.on('end', () => {
        try {
          const jsonData = JSON.parse(responseData);
          resolve({
            status: res.statusCode,
            headers: res.headers,
            data: jsonData
          });
        } catch (error) {
          resolve({
            status: res.statusCode,
            headers: res.headers,
            data: responseData,
            parseError: error.message
          });
        }
      });
    });

    req.on('error', (error) => {
      reject(error);
    });

    if (data) {
      req.write(JSON.stringify(data));
    }
    
    req.end();
  });
}

async function runTests() {
  console.log('🧪 Testing Smart Budget Backend API...\n');

  // Test 1: Health check
  console.log('1. Testing health endpoint...');
  try {
    const result = await testEndpoint('/api/health');
    console.log(`   ✅ Status: ${result.status}`);
    console.log(`   📄 Response: ${JSON.stringify(result.data, null, 2)}`);
  } catch (error) {
    console.log(`   ❌ Error: ${error.message}`);
    console.log('   🔧 Make sure backend is running: cd backend && npm start');
    return;
  }

  // Test 2: Register endpoint
  console.log('\n2. Testing register endpoint...');
  try {
    const testUser = {
      email: `test${Date.now()}@example.com`,
      password: 'testpassword123'
    };
    const result = await testEndpoint('/api/auth/register', 'POST', testUser);
    console.log(`   ✅ Status: ${result.status}`);
    console.log(`   📄 Response: ${JSON.stringify(result.data, null, 2)}`);
  } catch (error) {
    console.log(`   ❌ Error: ${error.message}`);
  }

  // Test 3: Login endpoint (with wrong credentials)
  console.log('\n3. Testing login endpoint...');
  try {
    const testUser = {
      email: 'nonexistent@example.com',
      password: 'wrongpassword'
    };
    const result = await testEndpoint('/api/auth/signin', 'POST', testUser);
    console.log(`   ℹ️  Status: ${result.status} (expected error for wrong credentials)`);
    console.log(`   📄 Response: ${JSON.stringify(result.data, null, 2)}`);
  } catch (error) {
    console.log(`   ❌ Error: ${error.message}`);
  }

  // Test 4: Transactions endpoint
  console.log('\n4. Testing transactions endpoint...');
  try {
    const result = await testEndpoint('/api/transactions?userId=test123');
    console.log(`   ✅ Status: ${result.status}`);
    console.log(`   📄 Response: ${JSON.stringify(result.data, null, 2)}`);
  } catch (error) {
    console.log(`   ❌ Error: ${error.message}`);
  }

  console.log('\n🎉 Backend API tests completed!');
  console.log('\n📝 Next steps:');
  console.log('   1. If all tests pass, the backend is working correctly');
  console.log('   2. Open frontend/debug.html in your browser to test frontend connectivity');
  console.log('   3. Check browser console for any JavaScript errors');
}

runTests().catch(console.error);
